# PRIMES AI privacy
This repo houses the code I developed during my first year with PRIMES, researching privacy methods for stability in AI. 
